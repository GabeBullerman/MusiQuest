package com.example.loginscreen;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterPage extends AppCompatActivity {
    EditText username;
    EditText password;
    EditText email;
    Button createAccountButton;
    Button backToLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        // Initialize UI elements after setContentView
        email = findViewById(R.id.userEmail);
        username = findViewById(R.id.newUsername);
        password = findViewById(R.id.newPassword);
        createAccountButton = findViewById(R.id.createAccount);
        backToLogin = findViewById(R.id.backToLogin);

        backToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent goToRegisterPage = new Intent(RegisterPage.this, MainActivity.class);
                startActivity(goToRegisterPage);
            }
        });
    }
}