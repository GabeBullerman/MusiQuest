package com.example.test;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    Button startBtn;
    Button backBtn;
    TextView numberTxt;
    Bundle a;
    String nickname;
    Random rand = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_activity);

        Intent intent1 = getIntent();
        a = intent1.getExtras();
        nickname = a.getString("nickname");

        startBtn = findViewById(R.id.startBtn);
        backBtn = findViewById(R.id.backBtn);
        numberTxt = findViewById(R.id.textView5);
        numberTxt.setText(nickname);

        TextView scoreTxt = findViewById(R.id.number);
        scoreTxt.setText(String.valueOf(rand.nextInt(500)));

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img = (ImageView) findViewById(R.id.imageView);
                img.setVisibility(View.VISIBLE);
            }
        });


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}